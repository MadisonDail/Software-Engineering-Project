import menu
import game
import pygame
menu.RunGame()

# Uncommment Below if want to run just game! 
# g=game.game()
# g.new()
# while g.running:
#     pygame.display.set_caption("Debug") #Updates caption for the game screen
#     g.main()
#     g.game_over()